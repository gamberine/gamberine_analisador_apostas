# Quina — Análise & Apostas (30/09/2025)

Publicação via GitHub Pages.
- Estilos externos: `gamb_variables_geral.css`
- Botões com classes `btn btnPrimary` e `btn btnSecondary`
- Cores de acerto usando `--primaryColor` e `--primaryColorHover`
- Acordeão na Parte 1 e responsivo (max-width: 1280px)

## Publicar no GitHub Pages
1. Crie um repositório (ex.: `quina-2025-09-30`).
2. Envie `index.html` para a branch `main`.
3. Em **Settings → Pages**:
   - **Source**: *Deploy from a branch*
   - **Branch**: `main` / **Folder**: `/ (root)`
4. URL: `https://<seu-usuario>.github.io/quina-2025-09-30/`
